# CS285 HW1 提交文件 - Imitation Learning

## 实验说明

本次提交包含 **Behavior Cloning (Q1)** 和 **DAgger (Q2)** 实验的完整结果。

### Q1: Behavior Cloning (行为克隆)

使用专家数据训练策略网络，单次迭代学习：

1. ✅ **BC Ant-v4** - 蚂蚁环境
2. ✅ **BC Walker2d-v4** - 双足行走器
3. ✅ **BC HalfCheetah-v4** - 半猎豹
4. ✅ **BC Hopper-v4** - 单足跳跃器

**关键发现**：
- Behavior Cloning 可以学习到接近专家的策略
- 性能取决于专家数据的质量和数量
- 某些环境（如 HalfCheetah）学习效果更好

### Q2: DAgger (Dataset Aggregation)

迭代式数据聚合，通过专家重新标注来改进策略：

1. ✅ **DAgger Ant-v4** (10 iterations)
2. ✅ **DAgger Walker2d-v4** (10 iterations)

**关键发现**：
- DAgger 通过迭代式查询专家显著提升性能
- 随着迭代次数增加，策略逐渐接近专家水平
- 相比纯 BC，DAgger 能更好地处理分布偏移问题

## 文件结构

```
hw1_submission/
├── runlogs/                    # TensorBoard 日志文件
│   ├── q1_bc_ant_Ant-v4_*/
│   ├── q1_bc_walker2d_Walker2d-v4_*/
│   ├── q1_bc_halfcheetah_HalfCheetah-v4_*/
│   ├── q1_bc_hopper_Hopper-v4_*/
│   ├── q2_dagger_ant_Ant-v4_*/
│   └── q2_dagger_walker2d_Walker2d-v4_*/
├── plots/                      # 可视化图表
│   ├── q1_bc_comparison.png
│   └── q2_dagger_learning_curves.png
├── cs285/                      # 源代码
│   ├── policies/
│   │   ├── MLP_policy.py
│   │   └── loaded_gaussian_policy.py
│   ├── infrastructure/
│   │   ├── utils.py
│   │   ├── logger.py
│   │   └── replay_buffer.py
│   └── scripts/
│       └── run_hw1.py
└── README.md                   # 本文件
```

## 如何查看 TensorBoard 日志

```bash
tensorboard --logdir=runlogs --port=6006
```

然后在浏览器访问: http://localhost:6006

可以查看：
- **Eval_AverageReturn**: 评估策略的平均回报
- **Train_AverageReturn**: 训练数据的平均回报
- **Initial_DataCollection_AverageReturn**: 初始数据收集的回报
- **videos**: 策略执行的可视化（如果启用）

## 实验参数

### Behavior Cloning (Q1)
- Iterations: 1
- Training steps per iter: 1000
- Batch size: 1000
- Learning rate: 5e-3
- Network: 2 layers × 64 units

### DAgger (Q2)
- Iterations: 10
- Training steps per iter: 1000
- Batch size: 1000 (per iteration)
- Learning rate: 5e-3
- Network: 2 layers × 64 units

## 主要代码实现

### 1. MLP_policy.py
实现了监督学习策略网络：
- `MLPPolicySL`: 多层感知机策略
- `update()`: 使用 MSE loss 更新策略参数

### 2. utils.py
实现了轨迹采样函数：
- `sample_trajectory()`: 采样单条轨迹
- `sample_trajectories()`: 采样多条轨迹
- `compute_metrics()`: 计算性能指标

### 3. run_hw1.py
实现了训练循环：
- Behavior Cloning: 从专家数据学习
- DAgger: 迭代式专家查询和数据聚合

## 环境配置

- Python: 3.9
- PyTorch: 2.7.0+cu128
- Gym: 0.25.2
- MuJoCo: 2.2.0
- GPU: CUDA enabled

## 性能对比

### BC vs Expert
查看 `plots/q1_bc_comparison.png` 了解各环境下 BC 策略相对专家的性能。

### DAgger 学习曲线
查看 `plots/q2_dagger_learning_curves.png` 了解 DAgger 的迭代学习过程。

---
生成时间: 2025-11-29
课程: UC Berkeley CS285 Deep Reinforcement Learning
作业: HW1 - Imitation Learning
