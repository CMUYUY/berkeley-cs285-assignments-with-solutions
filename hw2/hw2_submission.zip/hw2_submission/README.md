# CS285 HW2 提交文件

## 实验说明

本次提交包含 **Q2 CartPole 实验**的完整结果。

### 已完成的实验 (6/6)

#### Q2: CartPole-v0 策略梯度实验
1. `q2_sb_no_rtg_dna` - Small batch (b=1000), 无 reward-to-go
2. `q2_sb_rtg_dna` - Small batch + reward-to-go
3. `q2_sb_rtg_na` - Small batch + reward-to-go + baseline
4. `q2_lb_no_rtg_dna` - Large batch (b=5000), 无 reward-to-go
5. `q2_lb_rtg_dna` - Large batch + reward-to-go
6. `q2_lb_rtg_na` - Large batch + reward-to-go + baseline

### 未运行的实验

由于时间限制，以下实验未运行：
- Q3: InvertedPendulum 超参数搜索 (2个实验)
- Q4: LunarLander 连续控制 (1个实验)
- Q5: HalfCheetah 超参数对比 (2个实验)

## 文件结构

```
hw2_submission/
├── runlogs/           # TensorBoard 日志文件
│   ├── q2_pg_q2_sb_no_rtg_dna_CartPole-v0_*/
│   ├── q2_pg_q2_sb_rtg_dna_CartPole-v0_*/
│   ├── q2_pg_q2_sb_rtg_na_CartPole-v0_*/
│   ├── q2_pg_q2_lb_no_rtg_dna_CartPole-v0_*/
│   ├── q2_pg_q2_lb_rtg_dna_CartPole-v0_*/
│   └── q2_pg_q2_lb_rtg_na_CartPole-v0_*/
├── plots/             # 可视化图表
│   └── q2_cartpole_comparison.png
├── cs285/             # 源代码
│   ├── agents/
│   ├── networks/
│   ├── infrastructure/
│   └── scripts/
└── README.md          # 本文件
```

## 如何查看 TensorBoard 日志

```bash
tensorboard --logdir=runlogs --port=6006
```

然后在浏览器访问: http://localhost:6006

## 实验结果总结

### Q2 CartPole 对比

详见 `plots/q2_cartpole_comparison.png`

**主要发现**:
- Large batch (b=5000) 比 small batch (b=1000) 收敛更快
- Reward-to-go 显著提升训练效率
- Baseline (critic network) 进一步减少方差，提升稳定性

## 环境配置

- Python: 3.9+
- PyTorch: 2.7.0+cu128
- Gym: 0.25.2
- GPU: CUDA enabled

---
生成时间: 2025-11-29
